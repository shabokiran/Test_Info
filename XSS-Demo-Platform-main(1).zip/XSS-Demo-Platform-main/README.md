# XSS-Demo-Platform
XSS Attack &amp; Mitigation Demo Platform
